// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "FAUtilities.h"
#include "Interfaces/IPluginManager.h"

#if PLATFORM_WINDOWS
/*Open file dialog*/
#include "Microsoft/COMPointer.h"
//#include "DesktopPlatformModule.h"
#include <windows.h>  
#include <commdlg.h>  
#include <shobjidl.h>  
//#include <iostream>  
// 需要链接到shlwapi.lib和ole32.lib  
#pragma comment(lib, "shlwapi.lib")  
#pragma comment(lib, "ole32.lib")
/*Open file dialog*/

/*ExtractIcon*/
//#include <windows.h>    //<gdiplus.h><shellapi.h>dependent
#include <gdiplus.h>
#include <shellapi.h>
#pragma comment(lib, "gdiplus.lib")  //GetEncoderClsid()dependent
//using namespace Gdiplus;
/*ExtractIcon*/

/*CreateShortcut*/
#include "Windows/AllowWindowsPlatformTypes.h"
#include <objbase.h>
#include <ShlGuid.h>
#include <ShlObj.h>
#include "Windows/HideWindowsPlatformTypes.h"
/*CreateShortcutEnd*/

namespace FAUtilitiesProperty
{
	static bool bOpenedDialogPresent = false;
}

/*Saved/FileAssistant/IconSet*/
FString FAUtilities::GetFileAssistantName()
{
	static FString FileAssistantName(TEXT("FileAssistant"));
	return FileAssistantName;
}

FString FAUtilities::GetFileAssistantFolderPath()
{
	const FString FileAssistantPath = FPaths::Combine(FPaths::ProjectDir(),TEXT("Saved"),GetFileAssistantName());
	if(!FPaths::DirectoryExists(FileAssistantPath))
	{
		IFileManager& fileManager = IFileManager::Get();
		fileManager.MakeDirectory(*FileAssistantPath);
	}
	return FileAssistantPath;
}

FString FAUtilities::GetDefaultIconPath()
{
	return IPluginManager::Get().FindPlugin(GetFileAssistantName())->GetBaseDir() /"Resources"/"folder.png";
}

FString FAUtilities::GetToolBarIconPath()
{
	return IPluginManager::Get().FindPlugin(GetFileAssistantName())->GetBaseDir() /"Resources"/"Icon128.png";
}

FString FAUtilities::GetIconsDirectory()
{
	const FString IconsFolderPath = FPaths::Combine(GetFileAssistantFolderPath(),TEXT("IconSet"));

	if(!FPaths::DirectoryExists(IconsFolderPath))
	{
		IFileManager& fileManager = IFileManager::Get();
		fileManager.MakeDirectory(*IconsFolderPath);
	}
	return IconsFolderPath;
}

FString FAUtilities::GetShortcutsDirectory()
{
	const FString ShortcutsFolderPath = FPaths::Combine(GetFileAssistantFolderPath(),TEXT("Shortcuts"));
	
	if(!FPaths::DirectoryExists(ShortcutsFolderPath))
	{
		IFileManager& fileManager = IFileManager::Get();
		fileManager.MakeDirectory(*ShortcutsFolderPath);
	}
	return ShortcutsFolderPath;
}

bool FAUtilities::CreateShortcut(const TCHAR* InFilePath)
{
	const FString SavePath = FPaths::Combine(GetShortcutsDirectory(),FPaths::GetBaseFilename(InFilePath) + ".lnk");
	if(FPaths::FileExists(SavePath)) return false;
	if(!FPaths::DirectoryExists(InFilePath) && !FPaths::FileExists(InFilePath)) return false;
		
	if (!FWindowsPlatformMisc::CoInitialize()) {return false;}
	
	ON_SCOPE_EXIT { FWindowsPlatformMisc::CoUninitialize(); };
	
	IShellLink* ShellLink = nullptr;
	HRESULT Hres = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLink, reinterpret_cast<void**>(&ShellLink));
	if (FAILED(Hres) || !ShellLink) {return false;}
	
	ON_SCOPE_EXIT { SAFE_RELEASE(ShellLink); };

	IPersistFile* PersistFile = nullptr;
	Hres = ShellLink->QueryInterface(&PersistFile);
	if (FAILED(Hres) || !PersistFile) {return false;}
	
	ON_SCOPE_EXIT { SAFE_RELEASE(PersistFile); };
	
	ensure(SUCCEEDED(ShellLink->SetPath(InFilePath)));   //source file's full path
	//ensure(SUCCEEDED(ShellLink->SetArguments()));
	//ensure(SUCCEEDED(ShellLink->SetDescription()));  
	//ensure(SUCCEEDED(ShellLink->SetIconLocation()));   
	if (!ensure(SUCCEEDED(PersistFile->Save(*SavePath, true)))) {return false;} //save to full path
	
	if (PersistFile != nullptr) {  PersistFile->Release();  }  
	if (ShellLink != nullptr) {  ShellLink->Release();  }  
	
	CoUninitialize();
	
	return true;
}

FString FAUtilities::GetShortcutTargetPath(const TCHAR* InFilePath)
{
	FString Temp = FString();
	
	if (!FWindowsPlatformMisc::CoInitialize()){return Temp;}
	ON_SCOPE_EXIT { FWindowsPlatformMisc::CoUninitialize(); };
	
	IShellLink* ShellLink = nullptr;  
	HRESULT Hres = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLink, reinterpret_cast<void**>(&ShellLink));
   
	if (FAILED(Hres)) {  return Temp;  }  
  
	// open shortcut file  
	IPersistFile* PersistFile = nullptr;  
	Hres = ShellLink->QueryInterface(IID_IPersistFile, reinterpret_cast<void**>(&PersistFile));  
	if (FAILED(Hres)) {  
		ShellLink->Release();  
		return Temp;  
	}  
  
	// load shortcut file  
	Hres = PersistFile->Load(InFilePath, STGM_READ);  
	if (FAILED(Hres)) {  
		PersistFile->Release();  
		ShellLink->Release();  
		return Temp;  
	}  
  
	// get target path  
	TCHAR targetPath[MAX_PATH];  
	Hres = ShellLink->GetPath(targetPath, MAX_PATH, nullptr, 0);  
	if (FAILED(Hres)) {  
		PersistFile->Release();  
		ShellLink->Release();  
		return Temp;  
	}  
	
	// Release  
	if (PersistFile != nullptr){  PersistFile->Release();  }  
	if (ShellLink != nullptr){  ShellLink->Release();  }  
	CoUninitialize(); 
	return targetPath;
}

HICON FAUtilities::ExtractHIcon(const TCHAR* InFilePath)
{
	HICON hIcon = nullptr;
	
	SHFILEINFO sfi;  
	memset(&sfi, 0, sizeof(sfi));  
	
	if (SHGetFileInfo(InFilePath,  
					  FILE_ATTRIBUTE_NORMAL,  
					  &sfi,  
					  sizeof(sfi),  
					  SHGFI_ICON | SHGFI_USEFILEATTRIBUTES | SHGFI_LARGEICON))  
	{ hIcon = sfi.hIcon;}  
	//ExtractIconEx(filePath, 0, NULL, &hIcon, 1);
    
	return hIcon;
}

bool FAUtilities::GetEncoderClsid(const TCHAR* format, CLSID* pClsid)
{
	//using namespace Gdiplus; 
    
	UINT num = 0;  // number of image encoders  
	UINT size = 0; // size of the image encoder array in bytes  
  
	Gdiplus::GetImageEncodersSize(&num, &size);  
	if(size == 0) {return false;}
	// Failure  
  
	Gdiplus::ImageCodecInfo* pImageCodecInfo = (Gdiplus::ImageCodecInfo*)(malloc(size));  
	if(pImageCodecInfo == NULL) return false;  // Failure  
  
	GetImageEncoders(num, size, pImageCodecInfo);  
  
	for(UINT j = 0; j < num; ++j)  
	{  
		if( wcscmp(pImageCodecInfo[j].MimeType, format) == 0 )  
		{  
			*pClsid = pImageCodecInfo[j].Clsid;  
			free(pImageCodecInfo);
		            
			return true;  // Success  
		}      
	}  
	free(pImageCodecInfo);
   
	return false;  // Not found
}

bool FAUtilities::SaveIconToPng(const TCHAR* InFilePath)
{
	const FString SavePath = FPaths::Combine(GetIconsDirectory(),FPaths::GetBaseFilename(InFilePath) + ".png");
	if(FPaths::FileExists(SavePath)) return false;
	if(!FPaths::DirectoryExists(InFilePath) && !FPaths::FileExists(InFilePath)) return false;
	
	Gdiplus::GdiplusStartupInput gdiplusStartupInput;  
	ULONG_PTR gdiplusToken;  
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

	HICON hIcon = FAUtilities::ExtractHIcon(InFilePath);

	if(hIcon == nullptr) return false;
	
	Gdiplus::Bitmap* bitmap = Gdiplus::Bitmap::FromHICON(hIcon);
	//bitmap->SetResolution(32,32);
	
	if (bitmap == nullptr) return false;
	
	// 保存位图为PNG文件  
	CLSID pngClsid;
	FAUtilities::GetEncoderClsid(L"image/png", &pngClsid); // 需要一个辅助函数来获取PNG的CLSID  
	bitmap->Save(*SavePath, &pngClsid, NULL);
	
	// 清理
	DestroyIcon(hIcon);
	delete bitmap; 
	Gdiplus::GdiplusShutdown(gdiplusToken);
	
	return true;
}

bool FAUtilities::CopyTexture(const TCHAR* InFilePath)
{
	FString destinationPath = FPaths::Combine(GetIconsDirectory(), FPaths::GetBaseFilename(InFilePath)+".png");
	if(FPaths::FileExists(destinationPath)) return false;
	if(!FPaths::DirectoryExists(InFilePath) && !FPaths::FileExists(InFilePath)) return false;
	
	IPlatformFile& platformFile = FPlatformFileManager::Get().GetPlatformFile();

	return platformFile.CopyFile(*destinationPath,InFilePath);
}

bool FAUtilities::OpenFileOrFolder(const TCHAR* InPath)
{
	/*Handling the situation of double-clicking to open, InPath is shortcut path(file)*/
	if(FPaths::FileExists(InPath))
	{
		/*Is the target, whether it's a file or a folder, existing? if existing, open InPath*/
		if(FPaths::FileExists(GetShortcutTargetPath(InPath)) || FPaths::DirectoryExists(GetShortcutTargetPath(InPath)))
		{
			return FWindowsPlatformMisc::OsExecute(TEXT("open"),InPath,NULL);
		}
		else
		{
			return !DeleteMessageDialog(InPath);
		}
	}
	return false;
}

bool FAUtilities::OpenDirectory(const TCHAR* InPath)
{
	/*Handling the case of the open directory , InPath is shortcut path(file)*/
	if(FPaths::FileExists(InPath))
	{
		const FString TargetPath = GetShortcutTargetPath(InPath);
		if(FPaths::FileExists(TargetPath) || FPaths::DirectoryExists(TargetPath))
		{
			const FString TargetDirectoryPath = FPaths::GetPath(TargetPath);
			if(FPaths::DirectoryExists(TargetDirectoryPath))
			{
				return FWindowsPlatformMisc::OsExecute(TEXT("open"),*TargetDirectoryPath,NULL);
			}
		}
		else
		{
			return !DeleteMessageDialog(InPath);
		}
	}
	return false;
}

bool FAUtilities::DeleteIconAndShortcut(const TCHAR* InShortcutPath)
{
	if(!FPaths::FileExists(InShortcutPath)) return false;
	IPlatformFile& platformFile = FPlatformFileManager::Get().GetPlatformFile();
	return platformFile.DeleteFile(InShortcutPath);
	/*style initial test, if shortcut be ,style will delete icon as well*/
}

bool FAUtilities::RenameIconAndShortcut(const FString OldName,const FString NewName)
{
	if(OldName.Equals(NewName)) return false;
	
	const FString OldShortcutPath = FPaths::Combine(GetShortcutsDirectory(),OldName+".lnk");
	const FString OldIconPath = FPaths::Combine(GetIconsDirectory(),OldName+".png");
	FString NewShortcutPath = FPaths::Combine(GetShortcutsDirectory(),NewName+".lnk");
	FString NewIconPath = FPaths::Combine(GetIconsDirectory(),NewName+".png");
	
	IPlatformFile& platformFile = FPlatformFileManager::Get().GetPlatformFile();

	/*just test file , well folder icon may not exists*/
	if(!platformFile.FileExists(*OldShortcutPath)) return false;
	
	/*is icon path not exists , it is folder */
	bool IsFolder = !platformFile.FileExists(*OldIconPath);
	
	/*same name, append int until not as same*/
	int i = 1;
	while (platformFile.FileExists(*NewShortcutPath) && i<99)
	{
		NewShortcutPath = FPaths::Combine(GetShortcutsDirectory(),NewName+FString::FromInt(i)+".lnk");
		if(!IsFolder) //不是文件夹才更新icon路径, 若是文件夹就不动他了, 避免浪费性能
		{
			NewIconPath = FPaths::Combine(GetIconsDirectory(),NewName+FString::FromInt(i)+".png");
		}
		i++;
	}

	bool Process = false;
	/*if while 99 times, there will be true, fail*/
	if(!platformFile.FileExists(*NewShortcutPath)) 
	{
		/*move to same folder is rename*/
		platformFile.MoveFile(*NewShortcutPath,*OldShortcutPath);
		Process = true;
	}
	/*if while 99 times, there will be true, fail*/
	if(!IsFolder && !platformFile.FileExists(*NewIconPath))
	{
		platformFile.MoveFile(*NewIconPath,*OldIconPath);
		Process = true;
	}
	return Process;
}

bool FAUtilities::DeleteMessageDialog(const TCHAR* InPath)
{
	FText Title = FText::FromString(TEXT("Warning"));
	FText Message = FText::FromString(TEXT("The target does not exist on the disk. Do you want to delete the item?"));
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 2
	if(FMessageDialog::Open(EAppMsgType::OkCancel,Message,&Title) == EAppReturnType::Ok)
#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION > 2
	if(FMessageDialog::Open(EAppMsgType::YesNo,Message,Title) == EAppReturnType::Yes)
#endif
	{
		DeleteIconAndShortcut(InPath);
		return true;
	}
	return false;
}

bool FAUtilities::OpenSelectFileDialog(TArray<FString>& OutFilenames)
{
	SetIsOpenedDialogPresent(true);
	bool bSuccess = false;
	CoInitialize(NULL); 
  
	TComPtr<IFileDialog> FileDialog;  
	
	if (SUCCEEDED(::CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER,IID_IFileOpenDialog, IID_PPV_ARGS_Helper(&FileDialog))))
	{
		// Set this up as a multi-select picker
		DWORD dwFlags = 0;
		FileDialog->GetOptions(&dwFlags);
		FileDialog->SetOptions(dwFlags | FOS_ALLOWMULTISELECT);
		
		//Set dialog's title
		const FString DialogTitle = TEXT("Choose files...");
		FileDialog->SetTitle(*DialogTitle);

		//set default path, if not, show last time
		/*if (!DefaultPath.IsEmpty())
		{
			// SHCreateItemFromParsingName requires the given path be absolute and use \ rather than / as our normalized paths do
			FString DefaultWindowsPath = FPaths::ConvertRelativePathToFull(DefaultPath);
			DefaultWindowsPath.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);

			TComPtr<IShellItem> DefaultPathItem;
			if (SUCCEEDED(::SHCreateItemFromParsingName(*DefaultWindowsPath, nullptr, IID_PPV_ARGS(&DefaultPathItem))))
			{
				FileDialog->SetFolder(DefaultPathItem);
			}
		}*/
		
		// Set-up the file type filters
		const FString FileTypes = TEXT("All Files (*.*)|*.*|Image Files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|Document Files (*.doc;*.docx;*.pdf;*.txt)|*.doc;*.docx;*.pdf;*.txt");
		TArray<FString> UnformattedExtensions;
		TArray<COMDLG_FILTERSPEC> FileDialogFilters;
		{
			// Split the given filter string (formatted as "Pair1String1|Pair1String2|Pair2String1|Pair2String2") into the Windows specific filter struct
			FileTypes.ParseIntoArray(UnformattedExtensions, TEXT("|"), true);

			if (UnformattedExtensions.Num() % 2 == 0)
			{
				FileDialogFilters.Reserve(UnformattedExtensions.Num() / 2);
				for (int32 ExtensionIndex = 0; ExtensionIndex < UnformattedExtensions.Num();)
				{
					COMDLG_FILTERSPEC& NewFilterSpec = FileDialogFilters[FileDialogFilters.AddDefaulted()];
					NewFilterSpec.pszName = *UnformattedExtensions[ExtensionIndex++];
					NewFilterSpec.pszSpec = *UnformattedExtensions[ExtensionIndex++];
				}
			}
		}
		FileDialog->SetFileTypes(FileDialogFilters.Num(), FileDialogFilters.GetData());

		//show windows
		if (SUCCEEDED(FileDialog->Show(NULL)))
		{
			auto AddOutFilename = [&OutFilenames](const FString& InFilename)
			{
				FString& OutFilename = OutFilenames[OutFilenames.Add(InFilename)];
				//OutFilename = IFileManager::Get().ConvertToRelativePath(*OutFilename);
				FPaths::NormalizeFilename(OutFilename);
			};
			
			IFileOpenDialog* FileOpenDialog = static_cast<IFileOpenDialog*>(FileDialog.Get());
			TComPtr<IShellItemArray> Results;
			if (SUCCEEDED(FileOpenDialog->GetResults(&Results)))
			{
				DWORD NumResults = 0;
				Results->GetCount(&NumResults);
				for (DWORD ResultIndex = 0; ResultIndex < NumResults; ++ResultIndex)
				{
					TComPtr<IShellItem> Result;
					if (SUCCEEDED(Results->GetItemAt(ResultIndex, &Result)))
					{
						PWSTR pFilePath = nullptr;
						if (SUCCEEDED(Result->GetDisplayName(SIGDN_FILESYSPATH, &pFilePath)))
						{
							bSuccess = true;
							AddOutFilename(pFilePath);
							::CoTaskMemFree(pFilePath); //release memory
						}
					}
				}
			}
		}
	}  
  
	CoUninitialize();
	SetIsOpenedDialogPresent(false);
	return bSuccess;
}

bool FAUtilities::OpenSelectFolderDialog(FString& OutFolderName)
{
	SetIsOpenedDialogPresent(true);
	
	bool bSuccess = false;
	CoInitialize(NULL);

	TComPtr<IFileOpenDialog> FileDialog;
	if (SUCCEEDED(::CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&FileDialog))))
	{
		// Set this up as a folder picker
		{
			DWORD dwFlags = 0;
			FileDialog->GetOptions(&dwFlags);
			FileDialog->SetOptions(dwFlags | FOS_PICKFOLDERS);
		}

		//Set dialog's title
		const FString DialogTitle = TEXT("Choose a folder...");
		FileDialog->SetTitle(*DialogTitle);
		
		// Show the picker
		if (SUCCEEDED(FileDialog->Show(NULL)))
		{
			TComPtr<IShellItem> Result;
			if (SUCCEEDED(FileDialog->GetResult(&Result)))
			{
				PWSTR pFilePath = nullptr;
				if (SUCCEEDED(Result->GetDisplayName(SIGDN_FILESYSPATH, &pFilePath)))
				{
					bSuccess = true;

					OutFolderName = pFilePath;
					FPaths::NormalizeDirectoryName(OutFolderName);
					OutFolderName.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);
					
					::CoTaskMemFree(pFilePath);
				}
			}
		}
	}

	CoUninitialize();
	SetIsOpenedDialogPresent(false);
	return bSuccess;
}

bool FAUtilities::GetIsOpenedDialogPresent()
{
	return FAUtilitiesProperty::bOpenedDialogPresent;
}

void FAUtilities::SetIsOpenedDialogPresent(bool bIsDialogPresent)
{
	FAUtilitiesProperty::bOpenedDialogPresent = bIsDialogPresent;
}

#endif