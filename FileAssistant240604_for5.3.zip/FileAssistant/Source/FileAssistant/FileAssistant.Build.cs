// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

using UnrealBuildTool;

public class FileAssistant : ModuleRules
{
	public FileAssistant(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PublicIncludePaths.AddRange(new string[] { });
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				System.IO.Path.GetFullPath(Target.RelativeEnginePath) + "/Source/Runtime/Online/BuildPatchServices/Private",
				System.IO.Path.GetFullPath(Target.RelativeEnginePath) + "/Source/Runtime/Slate/Private",
				System.IO.Path.GetFullPath(Target.RelativeEnginePath) + "/Source/Runtime/SlateCore/Private",
			}
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"BuildPatchServices", 
				"SlateFileDialogs",
				"Slate",
				
				"UnrealEd",
				//"ContentBrowser",
				"InputCore",
				"Projects", 
				"SlateCore",
				"UMG",
				"DesktopPlatform"
			}
			);
		
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
				"ToolMenus",
				//"ContentBrowser",
				"UnrealEd"
			}
			);
		
		
		DynamicallyLoadedModuleNames.AddRange( new string[] { });
	}
}
