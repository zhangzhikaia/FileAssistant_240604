// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "FileAssistant.h"
#include "FAUtilities.h"
#include "DesktopPlatformModule.h"
#include "EditorDirectories.h"
#include "IconStyle.h"
#include "SFavoritesPanel.h"
#include "ToolMenus.h"
#include "HAL/FileManager.h"
#include "Misc/Paths.h"

#define LOCTEXT_NAMESPACE "FFileAssistantModule"

void FFileAssistantModule::StartupModule()
{
	FIconStyle::InitializeIcons();
	FToolBarIconStyle::Initialize();
	FToolBarIconStyle::ReloadTextures();

	//FileAssistantCommands::Register();
	
	//RegisterToolBarFAMenu();
	UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FFileAssistantModule::RegisterToolBarFAMenu));
	RegisterIconPanelTab();
}

void FFileAssistantModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	UToolMenus::UnregisterOwner(this);

	//FileAssistantCommands::Unregister();
	
	FIconStyle::ShutDownIcons();
	FToolBarIconStyle::ShutDown();
	
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(FName(FAUtilities::GetFileAssistantName()));
}

void FFileAssistantModule::RegisterToolBarFAMenu()
{
	FToolMenuOwnerScoped OwnerScoped(this);
	
	UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.PlayToolBar");
	
	FToolMenuSection& Section = ToolbarMenu->FindOrAddSection(FName(FAUtilities::GetFileAssistantName()));
	
	Section.AddEntry(FToolMenuEntry::InitToolBarButton(
		FName(FAUtilities::GetFileAssistantName()),
		FExecuteAction::CreateRaw( this, &FFileAssistantModule::OpenFileAssistantPanel),
		FText::FromString(FAUtilities::GetFileAssistantName()),
		FText::FromString("Open FileAssistant panel"),
		FSlateIcon(FToolBarIconStyle::GetToolBarStyleSetName(),"IconSet.ToolBarIcon")
		)
	);
}

void FFileAssistantModule::OpenFileAssistantPanel()
{
	FGlobalTabmanager::Get()->TryInvokeTab(FName(FAUtilities::GetFileAssistantName()));
}

void FFileAssistantModule::RegisterIconPanelTab()
{
	FGlobalTabmanager::Get()->RegisterTabSpawner(
		FName(FAUtilities::GetFileAssistantName()),
		FOnSpawnTab::CreateLambda([](const FSpawnTabArgs& SpawnTabArgs)
		{
			TSharedRef<SDockTab> TabPtr = SNew(SDockTab)
			.TabRole(ETabRole::NomadTab)
				[
					SNew(SFavoritesPanel)
				];
			TabPtr->SetTabIcon(FToolBarIconStyle::Get().GetBrush(FName("IconSet.ToolBarIcon")));
			return TabPtr;
		}));
}


bool FFileAssistantModule::ExecuteAddNewFile()
{
	bool bProcess = false;
	TArray<FString> OutFiles;
	
	if(FAUtilities::OpenSelectFileDialog(OutFiles))
	{
		for(FString CurrentFile : OutFiles)
		{
			/*As long as any one of them succeeds, it is set to true. */
			if(FAUtilities::CreateShortcut(*CurrentFile)){bProcess = true;}
			
			if(FPaths::GetExtension(CurrentFile).Equals(TEXT("jpg")) || FPaths::GetExtension(CurrentFile).Equals(TEXT("png")))
			{
				if(FAUtilities::CopyTexture(*CurrentFile)){bProcess = true;}
			}
			else
			{
				if(FAUtilities::SaveIconToPng(*CurrentFile)){bProcess = true;}
			}
		}
		if(bProcess){FIconStyle::RefreshSet();}
	}
	
	return bProcess;
}

bool FFileAssistantModule::ExecuteAddNewFolder()
{
	FString FolderPath;
	
	if(FAUtilities::OpenSelectFolderDialog(FolderPath))
	{
		return FAUtilities::CreateShortcut(*FolderPath);  
	}
	return false;
}

FFileAssistantModule& FFileAssistantModule::Get()
{
	return FModuleManager::LoadModuleChecked<FFileAssistantModule>(FName(FAUtilities::GetFileAssistantName()));
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FFileAssistantModule, FileAssistant)