﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "IconStyle.h"

#include "FAUtilities.h"
#include "Styling/SlateStyleMacros.h"
#include "Styling/SlateStyleRegistry.h"
#include "Styling/StyleColors.h"
#include "Styling/SlateStyle.h"

/*class FIconStyle*/
TSharedPtr<FSlateStyleSet> FIconStyle::CreatedSlateStyleSet = nullptr;

void FIconStyle::InitializeIcons()
{
	if(!CreatedSlateStyleSet.IsValid())
	{
		CreatedSlateStyleSet = CreateSlateStyleSet();
		FSlateStyleRegistry::RegisterSlateStyle(*CreatedSlateStyleSet);
	}
}

void FIconStyle::ShutDownIcons()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*CreatedSlateStyleSet);
	ensure(CreatedSlateStyleSet.IsUnique());
	CreatedSlateStyleSet.Reset();
}

void FIconStyle::RefreshSet(/*TArray<FString> AddFiles*/)
{
	ShutDownIcons();
	InitializeIcons();
}

const ISlateStyle& FIconStyle::Get()
{
	return *CreatedSlateStyleSet;
}

FName FIconStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("FAIconStyle"));
	return StyleSetName;
}

TSharedRef<FSlateStyleSet> FIconStyle::CreateSlateStyleSet()
{
	/*IMAGE_BRUSH macro dependent*/
	#define RootToContentDir CustomStyleSet->RootToContentDir
	
	TSharedRef<FSlateStyleSet> CustomStyleSet = MakeShareable(new FSlateStyleSet(GetStyleSetName()));
	
	const FString ShortcutDirectory = FAUtilities::GetShortcutsDirectory();
	/*IMAGE_BRUSH macro dependent*/
	CustomStyleSet->SetContentRoot(FAUtilities::GetIconsDirectory()); 

	IPlatformFile& platformFile = FPlatformFileManager::Get().GetPlatformFile();
	TArray<FString> FoundFiles;
	platformFile.FindFiles(FoundFiles,*FAUtilities::GetIconsDirectory(),*FString(TEXT("png")));
	
	for(FString currentFile : FoundFiles)
	{
		const FString ShortCutPath = FPaths::Combine(ShortcutDirectory,FPaths::GetBaseFilename(currentFile)+".lnk");
		if(platformFile.FileExists(*ShortCutPath))
		{
			const FName PropertyName = FName("IconSet."+FPaths::GetBaseFilename(currentFile));
			//CustomStyleSet->Set(PropertyName,new FSlateImageBrush(currentFile,Icon64x64));
			CustomStyleSet->Set(PropertyName, new IMAGE_BRUSH(FPaths::GetBaseFilename(currentFile), FVector2D(64.f,64.f)));
		}
		else
		{
			/*If the shortcut does not exist (has been deleted), delete the image as well.*/
			platformFile.DeleteFile(*currentFile);
		}
	}
	
	return CustomStyleSet;
}


/*class FToolBarIconStyle*/
TSharedPtr<FSlateStyleSet> FToolBarIconStyle::CreatedToolBarIconStyle = nullptr;

void FToolBarIconStyle::Initialize()
{
	if(!CreatedToolBarIconStyle.IsValid())
	{
		CreatedToolBarIconStyle = CreateToolBarIconStyle();
		FSlateStyleRegistry::RegisterSlateStyle(*CreatedToolBarIconStyle);
	}
}

void FToolBarIconStyle::ShutDown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*CreatedToolBarIconStyle);
	ensure(CreatedToolBarIconStyle.IsUnique());
	CreatedToolBarIconStyle.Reset();
}

void FToolBarIconStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FToolBarIconStyle::Get()
{
	return *CreatedToolBarIconStyle;
}

FName FToolBarIconStyle::GetToolBarStyleSetName()
{
	static FName StyleSetName(TEXT("FAToolBarIconStyle"));
	return StyleSetName;
}

TSharedRef<FSlateStyleSet> FToolBarIconStyle::CreateToolBarIconStyle()
{
	TSharedRef<FSlateStyleSet> CustomToolBarStyleSet = MakeShareable(new FSlateStyleSet(GetToolBarStyleSetName()));
	
	const FVector2D Icon64x64(64.f,64.f);

	CustomToolBarStyleSet->Set("IconSet.ToolBarIcon",new FSlateImageBrush(FAUtilities::GetToolBarIconPath(),Icon64x64));

	return CustomToolBarStyleSet;
}









