﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

class FFAItem;

DECLARE_DELEGATE_TwoParams( FOnRenameBegin, const TSharedPtr<FFAItem>& /*Item*/, const FString& /*OriginalName*/)
DECLARE_DELEGATE_ThreeParams( FOnRenameCommit, const TSharedPtr<FFAItem>& /*Item*/, const FString& /*NewName*/, ETextCommit::Type /*CommitType*/ )

class SFavoritesViewItem : public SCompoundWidget
{
	SLATE_BEGIN_ARGS(SFavoritesViewItem){}

	/** Data for the asset this item represents */
	SLATE_ARGUMENT(TSharedPtr<FFAItem>, FileItem)
	/** Delegate for when an asset name has entered a rename state */
	
	SLATE_EVENT(FOnRenameBegin, OnRenameBegin)
	/** Delegate for when an asset name has been entered for an item that is in a rename state */
	SLATE_EVENT(FOnRenameCommit, OnRenameCommit)
	
	SLATE_END_ARGS()
	
public:
	void Construct(const FArguments& InArgs);

private:
	
	/** Handles starting a name change */
	virtual void HandleBeginNameChange( const FText& OriginalText );

	/** Handles committing a name change */
	virtual void HandleNameCommitted( const FText& NewText, ETextCommit::Type CommitInfo );
	
	TSharedPtr< SInlineEditableTextBlock > InlineRenameWidget;
	
	/** The data for this item */
	TSharedPtr<FFAItem> FileItem;
	
	/** Delegate for when an item name has entered a rename state */
	FOnRenameBegin OnRenameBegin;

	/** Delegate for when an item name has been entered for an item that is in a rename state */
	FOnRenameCommit OnRenameCommit;
	
};
