﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

class FFAItem
{
public:
	FFAItem(FString InShortcutPath);

	FString GetShortcutPath();

	//FString GetDirectoryPath();

	FString GetBaseName();

	FName GetIconName();

	FString GetIconPath();
	
	/** Get the event fired whenever a rename is requested */
	FSimpleDelegate& OnRenameRequested();

	/** Get the event fired whenever a rename is canceled */
	FSimpleDelegate& OnRenameCanceled();
	
private:
	FString ShortcutPath;

	FString SourceFilePath; /*未设置*/
	FString IconPath; /*未设置*/
	FString DirectoryPath; /*未设置*/

	/** Broadcasts whenever a rename is requested */
	FSimpleDelegate RenameRequestedEvent;

	/** Broadcasts whenever a rename is canceled */
	FSimpleDelegate RenameCanceledEvent;
};
